import test from 'node:test';import assert from 'node:assert/strict';import {SONGS} from '../dist/catalog.js';import {Engine} from '../dist/engine.js';import {trackBestKey} from '../dist/library.js';
for(const song of SONGS){
 test(`${song.id}: EXTREME is denser and playable with two hands`,()=>{
  const notes=song.charts.extreme;assert.ok(notes,'EXTREME chart missing');assert.ok(notes.length>song.charts.hard.length*1.1);assert.ok(notes.some(n=>n.type==='slide'));assert.ok(notes.some(n=>n.type==='hold'));assert.ok(notes.some(n=>n.type==='flick'));assert.ok(notes.some((n,i)=>i&&n.t===notes[i-1].t),'Double notes missing');assert.ok(notes.some(n=>n.t>song.duration-10));
  for(let i=0;i<notes.length;i++){const n=notes[i];assert.ok(n.t>=0&&(n.end??n.t)<song.duration);for(let j=i-1;j>=0&&notes[j].t>n.t-1;j--){const p=notes[j];if((p.end??p.t)+.15>n.t)assert.notEqual(p.lane<2.5,n.lane<2.5,'Same hand required before release');}}
 });
 test(`${song.id}: EXTREME full chart completes at 60 FPS`,()=>{assert.ok(song.charts.extreme,'EXTREME chart missing');let e=new Engine(song.charts.extreme);for(let t=0;t<song.duration+1;t+=1/60){for(let n of e.notes){if(n.state==='pending'&&t>=n.t){e.down(n.id,n.lane,n.t);if(n.type==='flick')e.flick(n.id,n.lane,n.t);}if(n.end&&n.state==='hit'&&!n.tail)e.move(n.id,e.laneAt(n,t),t);}e.update(t);}assert.equal(e.stats.miss,0);assert.equal(e.score,1000000);});
}
test('All nine track/difficulty score records are independent',()=>assert.equal(new Set(SONGS.flatMap(s=>['normal','hard','extreme'].map(d=>trackBestKey(s.id,d)))).size,9));
