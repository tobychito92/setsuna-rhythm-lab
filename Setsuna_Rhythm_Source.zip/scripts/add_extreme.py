from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent

def extreme(source):
 notes=[];busy=[-1.,-1.];last=-1.;step=0
 for o in source['onsets']:
  t=o['t']
  if t<2.8 or t>source['duration']-2 or t-last<.112:continue
  free=[h for h in [0,1] if busy[h]+.155<t]
  if not free:continue
  hand=step%2
  if hand not in free:hand=free[0]
  local=[.15,1.2,2.0,1.1][(step//2)%4];lane=local+hand*3
  n={'t':round(t,4),'lane':lane,'span':1.05,'type':'tap','accent':'pink'}
  if step%19 in [8,17]:
   n.update(type='slide' if step%19==8 else 'hold',end=round(t+.42,4),endLane=(1.9 if local<1.2 else .2)+hand*3 if step%19==8 else lane)
  elif step%9==6:n.update(type='flick',accent='gold')
  notes.append(n);busy[hand]=n.get('end',t)
  if step%5==2 and 1-hand in free:
   other=1-hand;notes.append({'t':round(t,4),'lane':1.2+other*3,'span':1.05,'type':'tap','accent':'gold'});busy[other]=t
  last=t;step+=1
 return sorted(notes,key=lambda n:(n['t'],n['lane']))

p=root/'dist/chart.js';s=p.read_text();song=json.loads(s[len('export const SONG='):].strip().rstrip(';'));song['charts']['extreme']=extreme(json.loads((root/'analysis.json').read_text()));p.write_text('export const SONG='+json.dumps(song,ensure_ascii=False,separators=(',',':'))+';\n')
extras=[]
for id in ['upside-down-kiss','dance-with-you']:
 p=root/'data/tracks'/f'{id}.json';song=json.loads(p.read_text());song['charts']['extreme']=extreme(json.loads((root/'data/analysis'/f'{id}.json').read_text()));p.write_text(json.dumps(song,ensure_ascii=False,separators=(',',':')));extras.append(song)
(root/'dist/catalog.js').write_text("import {SONG} from './chart.js';\nexport const SONGS=[{...SONG,id:'setsuna-hanabi',audio:'song.mp3',cover:'assets/song-cover.webp'},"+','.join(json.dumps(s,ensure_ascii=False,separators=(',',':')) for s in extras)+'];\n')
print('EXTREME charts generated')
