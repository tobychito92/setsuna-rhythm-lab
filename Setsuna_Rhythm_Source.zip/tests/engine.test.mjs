import test from 'node:test';
import assert from 'node:assert/strict';
let module;try { module=await import('../dist/engine.js'); } catch {}
test('timing engine is available',()=>assert.ok(module,'Timing engine has not been implemented'));
test('nearest tap scores once and cannot be stolen by repeated taps',()=>{
 if(!module)return;let e=new module.Engine([{t:1,lane:2,type:'tap'}]);
 assert.equal(e.down('a',2,1.025)?.quality,'MARVELOUS');
 e.down('b',2,1.03);assert.equal(e.stats.judged,1);assert.equal(e.stats.combo,1);
});
test('hold release early loses its tail without erasing the head',()=>{
 if(!module)return;let e=new module.Engine([{t:1,lane:2,type:'hold',end:2,endLane:2}]);
 e.down('a',2,1);e.up('a',1.4);assert.equal(e.stats.judged,2);assert.equal(e.stats.miss,1);assert.equal(e.stats.marvelous,1);
});
test('two simultaneous holds stay assigned to independent fingers',()=>{
 if(!module)return;let e=new module.Engine([{t:1,lane:0,type:'hold',end:2,endLane:0},{t:1,lane:5,type:'hold',end:2,endLane:5}]);
 e.down('a',0,1);e.down('b',5,1);e.update(1.9);e.up('a',1.98);e.up('b',2);assert.equal(e.stats.miss,0);assert.equal(e.stats.judged,4);
});
test('flick requires upward motion; tapping alone expires as a miss',()=>{
 if(!module)return;let e=new module.Engine([{t:1,lane:1,type:'flick'}]);e.down('a',1,1);assert.equal(e.stats.judged,0);e.flick('a',1,1.04);assert.equal(e.stats.judged,1);
 let b=new module.Engine([{t:1,lane:1,type:'flick'}]);b.down('a',1,1);b.update(1.2);assert.equal(b.stats.miss,1);
});
test('missed hold head also accounts for tail, so result denominator stays correct',()=>{
 if(!module)return;let e=new module.Engine([{t:1,lane:1,type:'hold',end:2,endLane:1}]);e.update(3);assert.equal(e.stats.judged,e.total);assert.equal(e.stats.miss,2);
});
test('slide requires the finger to follow its target lane',()=>{
 if(!module)return;let e=new module.Engine([{t:1,lane:0,type:'slide',end:2,endLane:2}]);e.down('a',0,1);e.move('a',1,1.5);e.update(1.5);e.move('a',2,2);e.update(2);assert.equal(e.stats.miss,0);assert.equal(e.stats.judged,2);
 let b=new module.Engine([{t:1,lane:0,type:'slide',end:2,endLane:2}]);b.down('a',0,1);b.update(1.7);b.update(1.85);assert.equal(b.stats.miss,1);
});
test('pause clears fingers but allows a held note to be reacquired',()=>{
 if(!module)return;let e=new module.Engine([{t:1,lane:0,type:'hold',end:2,endLane:0}]);e.down('a',0,1);e.suspend();e.down('b',0,1.4);e.update(2);assert.equal(e.stats.miss,0);assert.equal(e.stats.judged,2);
});
import {SONG} from '../dist/chart.js';
for(let difficulty of ['normal','hard'])for(let fps of [30,60])test(`${difficulty} full chart can be completed without missing tails at ${fps} FPS`,()=>{
 let e=new module.Engine(SONG.charts[difficulty]);
 for(let t=0;t<=SONG.duration+1;t+=1/fps){
  for(let n of e.notes){if(n.state==='pending'&&t>=n.t){e.down('auto'+n.id,n.lane,n.t);if(n.type==='flick')e.flick('auto'+n.id,n.lane,n.t);}if(n.end&&n.state==='hit'&&!n.tail)e.move('auto'+n.id,e.laneAt(n,t),t);}
  e.update(t);
  for(let n of e.notes)if(n.tail&&e.fingers.has('auto'+n.id))e.up('auto'+n.id,t);
 }
 assert.equal(e.stats.miss,0);assert.equal(e.stats.judged,e.total);assert.equal(e.score,1000000);
});
test('both charts use actual audio onsets and remain inside the audio duration',()=>{
 for(let notes of Object.values(SONG.charts))for(let n of notes){assert.ok(n.t>0&&n.t<SONG.duration);assert.ok(n.lane>=0&&n.lane<=5);if(n.end)assert.ok(n.end>n.t&&n.end<SONG.duration);}
});
test('wide notes accept a press inside their visible span',()=>{let e=new module.Engine([{t:1,lane:2,type:'tap',span:2}]);e.down('a',2.9,1);assert.equal(e.stats.judged,1);});
test('pressing outside a narrow note does not steal its judgement',()=>{let e=new module.Engine([{t:1,lane:2,type:'tap',span:.7}]);e.down('a',2.9,1);assert.equal(e.stats.judged,0);});
