import test from 'node:test';import assert from 'node:assert/strict';
let fx;try{fx=await import('../dist/particles.js')}catch{}
test('expired judgement particles are excluded before Canvas receives a radius',()=>{assert.ok(fx,'Particle lifecycle needs a safe expiration boundary');let p={x:0,y:0,vx:0,vy:0,life:.01};assert.equal(fx.advanceParticle(p,1/30),false);});
test('live particles remain visible with a strictly positive lifetime',()=>{assert.ok(fx);let p={x:0,y:0,vx:1,vy:-1,life:1};assert.equal(fx.advanceParticle(p,1/60),true);assert.ok(p.life>0);assert.equal(p.x,1);});
