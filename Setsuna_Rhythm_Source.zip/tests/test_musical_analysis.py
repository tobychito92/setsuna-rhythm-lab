import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import numpy as np
try:from musical_chart import analyze,build_chart
except ImportError:analyze=build_chart=None
class AnalysisTests(unittest.TestCase):
 def test_silence_produces_no_notes(self):
  self.assertIsNotNone(analyze,'Layered musical analysis missing')
  a=analyze(np.zeros((22050*4,2)),22050);self.assertEqual(build_chart(a,'extreme'),[])
 def test_notes_follow_nonuniform_audible_attacks_and_real_sustain(self):
  self.assertIsNotNone(analyze,'Layered musical analysis missing')
  sr=22050;y=np.zeros((sr*8,2));rng=np.random.default_rng(3)
  for at in [1.,1.5,2.,3.,3.5,4.,5.,5.5,6.]:
   t=np.arange(int(sr*.09))/sr;burst=rng.normal(0,1,len(t))*np.exp(-t*60)*.3;y[int(at*sr):int(at*sr)+len(t)]+=burst[:,None]
  for at,pitch,length in [(1.23,330,.62),(2.37,440,.8),(4.21,392,.65),(6.22,494,.7)]:
   t=np.arange(int(sr*length))/sr;env=np.minimum(1,t/.015)*np.minimum(1,(length-t)/.04);tone=sum(np.sin(2*np.pi*pitch*k*t)/k for k in [1,2,3])*.25*env;y[int(at*sr):int(at*sr)+len(t)]+=tone[:,None]
  a=analyze(y,sr);all_events=a['events'];self.assertTrue(any(e['source']=='lead' for e in all_events));self.assertTrue(any(e['source']=='drums' for e in all_events))
  for at in [1.23,2.37,4.21,6.22]:self.assertLess(min(abs(e['t']-at) for e in all_events if e['source']=='lead'),.045)
  n=build_chart(a,'extreme');self.assertTrue(any(x.get('end',0)-x['t']>.35 for x in n));self.assertTrue(all('eventId' in x for x in n))
if __name__=='__main__':unittest.main()
