from pathlib import Path
import json,subprocess,shutil,sys
import numpy as np
from scipy import signal
from PIL import Image
from chart_patterns import make_charts
root=Path(__file__).resolve().parent.parent
item=json.loads(sys.argv[1]);src=Path(item.pop('input'))
(root/'dist/audio').mkdir(exist_ok=True);(root/'data/tracks').mkdir(parents=True,exist_ok=True);(root/'data/analysis').mkdir(parents=True,exist_ok=True)
audio='audio/'+item['id']+'.mp3';cover='assets/'+item['id']+'.webp'
shutil.copyfile(src,root/'dist'/audio)
r=subprocess.run(['ffmpeg','-v','error','-i',str(src),'-vn','-ac','1','-ar','22050','-f','f32le','pipe:1'],capture_output=True,check=True)
y=np.frombuffer(r.stdout,dtype=np.float32)
_,t,z=signal.stft(y,22050,nperseg=1024,noverlap=804)
f=signal.medfilt(np.maximum(0,np.diff(np.log1p(np.abs(z)*100),axis=1)).sum(axis=0),3)
peaks,_=signal.find_peaks(f,prominence=np.std(f)*.35,distance=12)
analysis={'duration':len(y)/22050,'onsets':[{'t':round(float(t[i+1]),4),'strength':round(float(f[i]),4)} for i in peaks]}
(root/'data/analysis'/ (item['id']+'.json')).write_text(json.dumps(analysis))
thumb=root/'data'/ (item['id']+'-art.png')
subprocess.run(['ffmpeg','-v','error','-i',str(src),'-an','-frames:v','1','-y',str(thumb)],check=True)
im=Image.open(thumb).convert('RGB');a=np.asarray(im);rows=np.mean(np.min(a,axis=2)<240,axis=1)>.05;idx=np.where(rows)[0]
if len(idx):im=im.crop((0,int(idx[0]),im.width,int(idx[-1])+1))
im.save(root/'dist'/cover,quality=92)
item.update(audio=audio,cover=cover,duration=analysis['duration'],revision='全曲起音分析譜 v0.4',charts=make_charts(analysis))
(root/'data/tracks'/ (item['id']+'.json')).write_text(json.dumps(item,ensure_ascii=False,separators=(',',':')))
print(item['id'],round(item['duration'],3),{k:len(v) for k,v in item['charts'].items()})
