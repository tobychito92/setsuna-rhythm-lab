# Legacy entry point: rebuild all musical charts from saved audio analysis.
from pathlib import Path
from musical_chart import run
run(Path(__file__).resolve().parent.parent,from_analysis=True)
