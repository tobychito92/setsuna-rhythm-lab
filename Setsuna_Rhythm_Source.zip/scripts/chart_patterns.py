def make_charts(source):
    onsets=source["onsets"]
    patterns=[[0,3,1,4,2,5,1,4],[1,4,0,3,2,5,2,3],[0,2,4,1,3,5,2,4],[2,5,1,4,0,3,1,5]]
    charts={}
    for difficulty,min_gap,threshold in [('normal',.275,.0),('hard',.165,0)]:
     selected=[]
     for o in onsets:
      if o['t']<2.8 or o['t']>source['duration']-3:continue
      if selected and o['t']-selected[-1]['t']<min_gap:
       if o['strength']>selected[-1]['strength']*1.6:selected[-1]=o
       continue
      selected.append(o)
     notes=[];occupied=[-1]*6;last=-1
     for i,o in enumerate(selected):
      t=o['t'];pattern=patterns[(i//32)%len(patterns)];lane=pattern[i%8]
      available=[l for l in range(6) if occupied[l]<t-.16]
      if not available:continue
      if lane not in available:lane=min(available,key=lambda x:abs(x-lane))
      n={'t':round(t,4),'lane':lane,'type':'tap'}
      gap=(selected[i+1]['t']-t) if i+1<len(selected) else 1
      if i%17==9 and gap>.31:
       # Short sustained gestures only where density allows; reserve the path.
       length=min(.7,max(.32,gap-.1));n.update(type='hold',end=round(t+length,4),endLane=lane);occupied[lane]=n['end']
       if i%34==9 and 0<lane<5:
        target=lane+(1 if lane<3 else -1)
        if occupied[target]<t-.16:n.update(type='slide',endLane=target);occupied[target]=n['end']
      elif i%11==7:n['type']='flick'
      notes.append(n)
      if difficulty=='hard' and i%13==4:
       other=lane+3 if lane<3 else lane-3
       if occupied[other]<t-.2:notes.append({'t':round(t,4),'lane':other,'type':'tap'})
     notes.sort(key=lambda n:(n['t'],n['lane']))
     for i,n in enumerate(notes):
      n['span']=[1.05,1.35,1.65,1.15,1.45][i%5]
      n['lane']=round(max(-.5+n['span']/2,min(5.5-n['span']/2,n['lane'])),3)
      if n.get('end'):n['endLane']=round(max(-.5+n['span']/2,min(5.5-n['span']/2,n['endLane'])),3)
      n['accent']='gold' if n['type']=='flick' or i%13<4 else 'pink'
     charts[difficulty]=notes
     print(difficulty,len(notes),{typ:sum(n['type']==typ for n in notes) for typ in ['tap','hold','slide','flick']})
    return charts
