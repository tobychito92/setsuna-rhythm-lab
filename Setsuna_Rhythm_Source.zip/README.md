# SETSUNA · Rhythm Lab — v0.5

Safari rhythm prototype using three user-provided MP3s. UI and note styling are inspired by the supplied Rhythm Hive gameplay recording; this is not a verified exact reproduction.

## Current layout

Both portrait and landscape work natively at the same URL. Portrait uses an upright, full-height playfield and unrotated pause/results dialogs. Landscape retains the wide reference-style playfield. There are no character cards, character portraits, or card image assets.

Tap, hold, trace a sustained path, or flick upward on a gold arrow. Variable-width notes have matching input areas. Keyboard fallback: S D F J K L. All tracks play their complete decoded duration and have NORMAL/HARD/EXTREME charts, pause/resume, audio calibration, approach speed and volume. Autoplay is demonstration-only and does not save best scores.

Settings can load an optional local MP4 as a muted background; the included MP3 remains the audio master. Without one, the song's embedded artwork is the background. The local video path still requires physical iOS testing.

## Files and checks

Buildless ES modules and assets are in `dist/`. `npm test` runs timing, sustained input, flick, full-chart simulations, and coordinate/geometry tests. `python3 scripts/build-offline.py /absolute/output.html` embeds all current assets/audio into a standalone HTML file. The hosted URL is recommended on iPhone because Files/ChatGPT previews may not execute standalone HTML.

The song library contains Setsuna Hanabi (226 seconds; NORMAL 415/HARD 765 notes), Upside Down Kiss (135 seconds; NORMAL 266/HARD 484) and HUENINGKAI — Dance With You (163 seconds; NORMAL 389/HARD 490). Each track/difficulty stores an independent best score; existing Setsuna full-song records remain readable. Only the selected audio is decoded to limit mobile memory use.

Initial charts are based on spectral-flux onsets with deterministic two-hand lane patterns. Holds and slides have head/tail scoring units. Chart quality still needs musical editing; they are not extracted original-game charts. Timing windows remain prototype choices: ±40/75/110/150 ms. Fonts, glow textures, rank thresholds and health-style display are approximations, not original game constants.

## Verification limits

Cloud Chromium viewport checks are not physical iPhone Safari tests. Real touch latency, Bluetooth delay, device rotation during sustained multi-touch, original-game feel, local MP4 decoding and thermal behavior are unverified. The supplied recording is a compilation of different songs; it provides gameplay layout reference, not song selection or original chart data.

EXTREME 16 adds denser onset-driven alternation, doubles, flicks and sustained gestures, with at most one active gesture per hand. The original NORMAL/HARD charts and their score keys are unchanged. Regenerate EXTREME using `python3 scripts/add_extreme.py`.
