import test from 'node:test';import assert from 'node:assert/strict';
let view;try{view=await import('../dist/view-geometry.js')}catch{}
test('reference geometry uses two judgement lines at the measured landscape positions',()=>{assert.ok(view,'Reference geometry missing');let g=view.geometry(1362,629);assert.equal(g.upper,629*.68);assert.equal(g.lower,629*.79);assert.equal(g.hit,629*.735);});
test('portrait touches use upright screen coordinates without rotation',()=>{assert.ok(view);let p=view.toStage(300,200,{left:0,top:0,right:390,width:390,height:844},390,844);assert.deepEqual(p,{x:300,y:200});});
test('landscape letterboxing subtracts screen offsets before hit testing',()=>{assert.ok(view);assert.deepEqual(view.toStage(200,300,{left:100,top:150,width:844,height:390},844,390,false),{x:100,y:150});});
test('a note center maps to the same logical lane across the whole judgement band',()=>{assert.ok(view);for(let lane=0;lane<6;lane++){let g=view.geometry(844,390),x=view.laneX(lane,g.hit,g);assert.ok(Math.abs(view.inputLane(x,g)-lane)<1e-9);}});
test('portrait geometry provides an upright full-height runway',()=>{let g=view.geometry(390,844);assert.equal(g.hit,844*.8);assert.equal(g.top,844*.14);assert.ok(g.lower>g.hit&&g.upper<g.hit);for(let lane=0;lane<6;lane++)assert.ok(Math.abs(view.inputLane(view.laneX(lane,g.hit,g),g)-lane)<1e-9);});
