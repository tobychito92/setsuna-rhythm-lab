import test from 'node:test';import assert from 'node:assert/strict';
let clock;try{clock=await import('../dist/clock.js')}catch{}
test('resume countdown freezes chart and judgement at resume position',()=>{assert.ok(clock,'Resume clock missing');const x=clock.timeline(9,10,50);assert.equal(x.chart,9.95);assert.equal(x.active,false);assert.equal(x.countdown,-1);});
test('after countdown the chart follows audible time with calibration',()=>{assert.ok(clock);const x=clock.timeline(11,10,50);assert.equal(x.chart,10.95);assert.equal(x.active,true);});
