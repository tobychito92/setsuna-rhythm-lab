from pathlib import Path
import re,base64,json,sys,subprocess
root=Path(__file__).resolve().parent.parent/'dist'
out=Path(sys.argv[1]).resolve()
html=(root/'index.html').read_text()
html=re.sub(r'<link rel="stylesheet" href="style.css[^\"]*">',lambda m:'<style>'+(root/'style.css').read_text()+'</style>',html)
assets={}
for f in (root/'assets').glob('*.webp'):
 key='assets/'+f.name;data='data:image/webp;base64,'+base64.b64encode(f.read_bytes()).decode();assets[key]=data;html=html.replace('src="'+key+'"','src="'+data+'"')
code=[]
for name in ['engine.js','clock.js','view-geometry.js','reference-view.js','chart.js','catalog.js','library.js','app.js']:
 s=(root/name).read_text()
 s=re.sub(r'^import .*?;\s*','',s,flags=re.M)
 s=re.sub(r'\bexport (?=(?:const|function|class)\b)','',s)
 code.append(s)
catalog=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import {SONGS} from './dist/catalog.js';console.log(JSON.stringify(SONGS.map(({id,audio})=>({id,audio}))));"],cwd=root.parent,text=True))
audio={song['id']:base64.b64encode((root/song['audio']).read_bytes()).decode() for song in catalog}
embedded='<script>window.EMBEDDED_AUDIO='+json.dumps(audio)+';window.EMBEDDED_ASSETS='+json.dumps(assets)+';</script><script type="module">'+'\n'.join(code)+'</script>'
html=re.sub(r'<script type="module" src="app.js[^\"]*"></script>',lambda m:embedded,html)
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(html)
assert not re.search(r'(?:src|href)="(?:app.js|style.css|assets/)',html)
assert not re.search(r'^import ',html,re.M)
print(out)
