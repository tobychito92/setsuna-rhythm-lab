import test from 'node:test';import assert from 'node:assert/strict';
let catalog,library;try{catalog=await import('../dist/catalog.js');library=await import('../dist/library.js')}catch{}
test('song library contains the original song and both supplied uploads',()=>{assert.ok(catalog,'Three-song catalog is missing');assert.deepEqual(catalog.SONGS.map(s=>s.id),['setsuna-hanabi','upside-down-kiss','dance-with-you']);});
test('full-song duration uses the entire decoded audio, including anything after 90 seconds',()=>{assert.ok(library,'Full-song session rules missing');assert.equal(library.fullTrackEnd(226.139),226.139);assert.equal(library.fullTrackEnd(135.08),135.08);assert.equal(library.fullTrackEnd(163.37),163.37);});
test('best score keys are isolated by song and difficulty',()=>{assert.ok(catalog&&library);let keys=catalog.SONGS.flatMap(s=>['normal','hard'].map(d=>library.trackBestKey(s.id,d)));assert.equal(new Set(keys).size,6);});
test('the complete chart retains a note after 90 seconds and at the track tail',()=>{assert.ok(library);let s={charts:{normal:[{t:2,lane:1,type:'tap'},{t:100,lane:2,type:'tap'},{t:134.7,lane:3,type:'hold',end:135,endLane:3}]}};assert.equal(library.fullChart(s,'normal',135.08).length,3);});
import {Engine} from '../dist/engine.js';
if(catalog)for(const song of catalog.SONGS.slice(1))for(const difficulty of ['normal','hard'])test(`${song.id} ${difficulty} full chart completes at 60 FPS`,()=>{
 let e=new Engine(library.fullChart(song,difficulty,song.duration));
 assert.ok(e.notes.some(n=>n.t>90),'Song must have notes after 90 seconds');
 for(let t=0;t<song.duration+1;t+=1/60){for(let n of e.notes){if(n.state==='pending'&&t>=n.t){e.down(n.id,n.lane,n.t);if(n.type==='flick')e.flick(n.id,n.lane,n.t);}if(n.end&&n.state==='hit'&&!n.tail)e.move(n.id,e.laneAt(n,t),t);}e.update(t);}
 assert.equal(e.stats.miss,0);assert.equal(e.stats.judged,e.total);assert.equal(e.score,1000000);
});
