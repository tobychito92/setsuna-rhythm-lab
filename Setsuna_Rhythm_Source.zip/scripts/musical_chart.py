"""Offline stereo HPSS/band-onset charting. Lead is a center-harmonic estimate,
not an isolated vocal stem. Every chart head references a measured event."""
import json,subprocess
from pathlib import Path
import numpy as np
from scipy import signal,ndimage

def analyze(y,sr):
 y=np.asarray(y,dtype=np.float32)
 if y.ndim==1:y=np.column_stack([y,y])
 hop=round(sr*.01);nfft=2048;dt=hop/sr
 mid=y.mean(axis=1);side=(y[:,0]-y[:,1])*.5
 f,t,z=signal.stft(mid,sr,nperseg=nfft,noverlap=nfft-hop,boundary='zeros');m=np.abs(z).astype(np.float32)
 _,_,zs=signal.stft(side,sr,nperseg=nfft,noverlap=nfft-hop,boundary='zeros');s=np.abs(zs).astype(np.float32)
 if np.max(m)<1e-7:return {'duration':len(y)/sr,'events':[],'bpm':0,'method':'stereo-hpss-onset-v6'}
 h=ndimage.median_filter(m,size=(1,21));p=ndimage.median_filter(m,size=(17,1));hm=h*h/(h*h+p*p+1e-12);pm=1-hm
 center=np.clip(m/(m+s+1e-7),.15,1)
 bands={'drums':m*pm*((f>=35)&(f<8000))[:,None], 'lead':m*hm*center**2*((f>=180)&(f<3000))[:,None], 'backing':(m+s)*hm*((f>=100)&(f<6000))[:,None]}
 # Harmonic template estimates pitch movement, without claiming voice transcription.
 midis=np.arange(48,85);template=np.zeros((len(midis),len(f)),np.float32)
 for k,midi in enumerate(midis):
  hz=440*2**((midi-69)/12)
  for harmonic in [1,2,3,4]:template[k]+=np.exp(-.5*((f-hz*harmonic)/(sr/nfft*.7))**2)/harmonic
 pitch_strength=template@bands['lead'];pitch=midis[np.argmax(pitch_strength,axis=0)]
 events=[];novelties={};energies={}
 for source,mag in bands.items():
  flux=np.maximum(0,np.diff(np.log1p(mag*200),axis=1)).sum(axis=0);flux=np.r_[0,flux];flux=ndimage.gaussian_filter1d(flux,.65)
  med=ndimage.median_filter(flux,size=81);mad=ndimage.median_filter(np.abs(flux-med),size=81)
  baseline=med+np.maximum(np.percentile(flux,75)*.14,mad*.8)
  peaks,_=signal.find_peaks(flux,height=baseline,prominence=max(.02,float(np.percentile(flux,85)*.09)),distance=max(1,round(.075/dt)))
  energy=np.sqrt((mag*mag).sum(axis=0));energies[source]=energy;novelties[source]=flux
  scale=max(1e-8,float(np.percentile(flux[peaks],80))) if len(peaks) else 1
  for idx in peaks:
   # Flux peaks occur on the rising edge of a centered STFT. Retain that attack time.
   at=float(t[idx]);strength=float(flux[idx]/scale)
   if at<.45 or at>len(y)/sr-.5 or energy[idx]<np.max(energy)*.025:continue
   e={'t':round(at,4),'source':source,'strength':round(strength,4),'pitch':int(pitch[idx]),'frame':int(idx)}
   if source=='drums':
    e['high']=bool(np.sum(m[f>2200,idx]*pm[f>2200,idx])>np.sum(m[f<250,idx]*pm[f<250,idx])*1.4)
   events.append(e)
 events.sort(key=lambda e:(e['t'],e['source']))
 lead=sorted([e for e in events if e['source']=='lead'],key=lambda e:e['t'])
 for i,e in enumerate(lead):
  idx=e['frame'];limit=min(len(t)-1,idx+round(1.2/dt));next_t=lead[i+1]['t'] if i+1<len(lead) else len(y)/sr
  # Follow the actual harmonic energy envelope; stop at the next lead articulation.
  ref=np.max(energies['lead'][idx:min(limit,idx+8)+1]);endidx=idx
  for j in range(idx+1,limit+1):
   if t[j]>next_t-.06 or energies['lead'][j]<ref*.42:break
   endidx=j
  duration=t[endidx]-e['t']
  if duration>=.28:
   e['sustainEnd']=round(float(t[endidx]),4);tail=int(pitch[max(idx,endidx-3)]);e['pitchEnd']=tail
 # Autocorrelation provides a tempo candidate only; note times never come from a free-running timer.
 drum=novelties['drums'];ac=signal.fftconvolve(drum-drum.mean(),(drum-drum.mean())[::-1],mode='full')[len(drum)-1:]
 lo,hi=round(60/190/dt),round(60/70/dt);lags=np.arange(lo,min(hi,len(ac)-1)+1)
 lag=lags[np.argmax(ac[lags]*(.85+.15*np.exp(-((60/(lags*dt)-120)/50)**2)))] if len(lags) else 0
 for i,e in enumerate(events):e['id']=i;e.pop('frame',None)
 return {'duration':len(y)/sr,'events':events,'bpm':round(60/(lag*dt),2) if lag else 0,'method':'stereo-hpss-onset-v6','leadCaveat':'Center harmonic estimate; includes lead instruments, not isolated vocals.'}

def build_chart(a,difficulty):
 cfg={'normal':(.29,.83,.85),'hard':(.18,.52,.62),'extreme':(.115,.27,.38)}[difficulty];gap,threshold,backing_threshold=cfg
 events=a['events'];notes=[];busy=[-1.,-1.];last_global=-1.;last_hand=1
 for e in events:
  if e['strength']<(backing_threshold if e['source']=='backing' else threshold):continue
  at=e['t']
  if at<1 or at>a['duration']-.65:continue
  free=[h for h in [0,1] if busy[h]+.16<at]
  if not free:continue
  # Separate layers may become a double only on the same audible attack.
  near=notes and abs(at-notes[-1]['t'])<=.025
  if near:
   if difficulty=='normal' or notes[-1]['source']==e['source'] or sum(abs(n['t']-notes[-1]['t'])<.001 for n in notes[-2:])>=2:continue
   at=notes[-1]['t'];free=[h for h in free if busy[h]+.16<at]
   if e['strength']<.85 or not free:continue
  elif at-last_global<gap:continue
  hand=1-last_hand
  if hand not in free:hand=free[0]
  pitch=(e['pitch']-48)%12;local=.15+pitch/11*1.85 if e['source']!='drums' else (.2 if not e.get('high') else 1.9)
  lane=round(local+hand*3,3);n={'t':round(at,4),'lane':lane,'span':1.15 if difficulty=='normal' else 1.05,'type':'tap','accent':'gold' if e['source']=='drums' else 'pink','source':e['source'],'eventId':e['id'],'attackTime':e['t']}
  end=e.get('sustainEnd',at)
  if e['source']=='lead' and end-at>=(.42 if difficulty=='normal' else .3):
   n.update(type='hold',end=end,endLane=lane)
   if difficulty!='normal' and 2<=abs(e.get('pitchEnd',e['pitch'])-e['pitch'])<=7:
    tail=round(.15+((e['pitchEnd']-48)%12)/11*1.85+hand*3,3);n.update(type='slide',endLane=tail)
  elif difficulty!='normal' and e['source']=='drums' and e.get('high') and e['strength']>1.3:n['type']='flick'
  notes.append(n);busy[hand]=n.get('end',at);last_hand=hand;last_global=at
 return sorted(notes,key=lambda n:(n['t'],n['lane']))

def run(root,from_analysis=False):
 root=Path(root);first=json.loads((root/'dist/chart.js').read_text().split('=',1)[1].strip().rstrip(';'));first.update(id='setsuna-hanabi',audio='song.mp3',cover='assets/song-cover.webp')
 songs=[first]+[json.loads((root/'data/tracks'/f'{i}.json').read_text()) for i in ['upside-down-kiss','dance-with-you']]
 (root/'data/musical').mkdir(parents=True,exist_ok=True)
 for song in songs:
  print('Analyzing',song['id'],flush=True)
  if from_analysis:a=json.loads((root/'data/musical'/f"{song['id']}.json").read_text())
  else:
   raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(root/'dist'/song['audio']),'-vn','-ac','2','-ar','22050','-f','f32le','pipe:1']);y=np.frombuffer(raw,dtype=np.float32).reshape(-1,2)
   a=analyze(y,22050)
  (root/'data/musical'/f"{song['id']}.json").write_text(json.dumps(a,separators=(',',':')))
  song['charts']={d:build_chart(a,d) for d in ['normal','hard','extreme']};song['chartRevision']='musical-v6';song['revision']='鼓點・主旋律・伴奏分層譜 v0.6';song['bpmEstimate']=a['bpm']
  print(song['id'],a['bpm'],{d:len(ns) for d,ns in song['charts'].items()},flush=True)
  if song is first:(root/'dist/chart.js').write_text('export const SONG='+json.dumps(song,ensure_ascii=False,separators=(',',':'))+';\n')
  else:(root/'data/tracks'/f"{song['id']}.json").write_text(json.dumps(song,ensure_ascii=False,separators=(',',':')))
 (root/'dist/catalog.js').write_text("import {SONG} from './chart.js';\nexport const SONGS=[SONG,"+','.join(json.dumps(s,ensure_ascii=False,separators=(',',':')) for s in songs[1:])+'];\n')
if __name__=='__main__':
 import sys
 run(Path(__file__).resolve().parent.parent,'--from-analysis' in sys.argv)
