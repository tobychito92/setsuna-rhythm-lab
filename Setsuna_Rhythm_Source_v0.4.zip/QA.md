# QA — 2026-11-15

## Automated evidence

17 Node tests pass, including one-hit-only tap scoring; early hold release; two independent simultaneous holds; upward flick requirements; missed hold denominator; slide following; hold reacquisition; full-chart autoplay simulations for both difficulties at 30 and 60 FPS; resume countdown freeze; audible-clock offset; and expired particle rejection.

Chart audit: NORMAL maximum four notes per second and one simultaneous required finger. HARD maximum six notes per second and two simultaneous required fingers. Neither chart places a new head into an occupied held lane. Both charts finish at one million with zero misses under ideal deterministic autoplay.

Standalone HTML passes JS syntax validation, contains its audio and style assets, and has no module imports.

## Browser evidence

Desktop menu, mobile 390×844 menu, touch-stage layout, settings, and playback have been visually inspected in cloud Chromium. An actual runtime crash was found in expired particle rendering (negative Canvas radius); it was fixed by excluding expired particles before drawing, with regression coverage. Resume countdown also freezes judgement rather than scoring misses while waiting.

Browser autoplay and pause/resume are checked separately from unit simulations. Results from the final browser run are recorded after that run finishes.

## Not tested

Physical iPhone/iPad Safari, real multi-finger hardware input, measured audio-to-touch latency, Bluetooth calibration, 100% equivalence to Rhythm Hive, subjective chart quality, and exact target-game judgement constants. No claim of 100% parity is supported by these checks.

Final browser run: HARD 90-second autoplay completed after pause/resume at about 42 seconds. Result screen displayed 1,000,000 points, 100.00% accuracy, maximum combo 281, MARVELOUS 281 and MISS 0. No application error after the particle fix appeared in the captured app.js log; the earlier pre-fix error remains in the tab's log history. The mobile result screen fits its 390×844 viewport. This demonstrates the corrected browser pipeline, not human touch accuracy.


## v0.2 recording comparison — 2026-11-15

23 tests pass, including the original suite plus reference geometry, landscape letterbox coordinates, portrait inverse rotation, fixed judgement-band lane mapping, and variable-width hit areas. Both full charts still complete at 30/60 FPS in deterministic input simulation.

Cloud Chromium 844×390 browser run: HARD 90-second autoplay reaches the result screen at 1,000,000, 100.00%, combo 281, MISS 0. Portrait 390×844 rotates the stage and card/HUD layout correctly; the rotated pause dialog and resume countdown have been inspected and operated. Console inspection shows only the cloud browser's extension metadata warnings, no application errors during the inspected run.

Unverified: physical iPhone Safari, human multi-touch and flick feel, local MP4 import/playback on hardware, exact original game font/sprite equivalence, and 100% visual/behavioral parity. All visual measurements are approximations from the supplied recording.

## v0.3 upright layouts

Removed character card markup, styles, and raster assets. Replaced forced portrait rotation with native 390×844 portrait layout. Added portrait geometry and upright coordinate regression coverage (24 tests total). Landscape 844×390 and portrait 390×844 playfields were inspected running in Chromium; both have no character cards. The portrait pause dialog and resume button were operated and are upright. Real iPhone Safari remains untested.

## v0.4 full song library

32 Node tests pass. Added all three catalog entries, independent per-track/difficulty best-score keys, removal of the 90-second cutoff, retention of chart events near the actual audio end, and full-chart 60 FPS simulations for both new tracks at both difficulties. All four new chart simulations reach one million with zero misses. All playable lengths use decoded audio duration. New-song charts are generated from their own spectral-flux onsets; they are not original Rhythm Hive charts. Physical iPhone Safari remains untested.

Cloud Chromium full-length browser runs: portrait 390×844 Upside Down Kiss NORMAL completed at 1,000,000, 100.00%, combo 281, MISS 0; landscape 844×390 Dance With You HARD completed at 1,000,000, 100.00%, combo 498, MISS 0. Both passed 90 seconds and reached their actual audio ends. Return to song selection and switch back to Setsuna Hanabi were verified. Browser logs inspected showed extension metadata warnings only, no application error in the inspected run. These were autoplay demonstrations, not hardware touch tests.
